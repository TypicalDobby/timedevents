NPCSpawner = NPCSpawner or {}

-- Default settings (can be changed here or with the admin config menu in game)
NPCSpawner.spawnInterval = 30
NPCSpawner.npcClass = "npc_antlion"
NPCSpawner.npcCount = 10
NPCSpawner.propModel = "models/props_c17/oildrum001.mdl"
NPCSpawner.enemyNPCClass = "npc_zombie"

-- List of spawn locations (adjust vectors to where you want them to spawn, I'd suggest the vector tool addon to get a solid vector reading)
NPCSpawner.spawnLocations = {
    {pos = Vector(-6108, 2250, -13710), message = "Alert! Hostile activity detected near the northern base!"},
    {pos = Vector(-7901, -11106, -13600), message = "Warning! Hostile activity spotted near the northern cliffs!"}, -- broadcast messages when npcs are spawned can change to whatever you want :D
    {pos = Vector(-9313, 6734, -15600), message = "Attention! Rumblings are coming from the caverns, suspected hostile creatures!"},
}

if SERVER then

    function NPCSpawner:SpawnNPCs()
        local locationData = self.spawnLocations[math.random(1, #self.spawnLocations)]
        local spawnPos = locationData.pos
        local customMessage = locationData.message

        for i = 1, self.npcCount do
            local npc = ents.Create(self.npcClass)
            if IsValid(npc) then
                npc:SetPos(spawnPos + Vector(math.random(-850, 350), math.random(-850, 150), 10))
                npc:Spawn()
            else
                print("[NPC Spawner] Failed to create NPC with class: " .. tostring(self.npcClass))
            end
        end

        for _, player in ipairs(player.GetAll()) do
            player:ChatPrint(customMessage)
        end
    end

    function NPCSpawner:SpawnCargoTransport()
        local locationData = self.spawnLocations[math.random(1, #self.spawnLocations)]
        local spawnPos = locationData.pos
        local customMessage = "Cargo transport sighted at a location! Hostile forces have been detected guarding it!" -- Broadcast when cargo is spawned can change to whatever you want :)

        local cargo = ents.Create("prop_physics")
        if IsValid(cargo) then
            cargo:SetModel(self.propModel)
            cargo:SetPos(spawnPos + Vector(0, 0, 10))
            cargo:Spawn()
        else
            print("[NPC Spawner] Failed to spawn cargo prop with model: " .. tostring(self.propModel))
            return
        end

        for i = 1, 5 do
            local npc = ents.Create(self.enemyNPCClass)
            if IsValid(npc) then
                npc:SetPos(spawnPos + Vector(math.random(-100, 100), math.random(-100, 100), 10))
                npc:Spawn()
            else
                print("[Cargo Event] Failed to create enemy NPC with class: " .. tostring(self.enemyNPCClass))
            end
        end

        for _, player in ipairs(player.GetAll()) do
            player:ChatPrint(customMessage)
        end
    end

    function NPCSpawner:StartEventSpawner()
        timer.Create("EventSpawnerTimer", self.spawnInterval, 0, function()
            local eventType = math.random(1, 2)
            if eventType == 1 then
                self:SpawnNPCs()
            else
                self:SpawnCargoTransport()
            end
        end)
    end

    function NPCSpawner:StopEventSpawner()
        if timer.Exists("EventSpawnerTimer") then
            timer.Remove("EventSpawnerTimer")
        end
    end

    util.AddNetworkString("NPCSpawner_OpenAdminMenu")
    util.AddNetworkString("NPCSpawner_UpdateSettings")
    util.AddNetworkString("NPCSpawner_StartEvent")
    util.AddNetworkString("NPCSpawner_StopEvent")

    net.Receive("NPCSpawner_UpdateSettings", function(len, ply)
        if ply:IsAdmin() then
            NPCSpawner.spawnInterval = net.ReadInt(32)
            NPCSpawner.npcClass = net.ReadString()
            NPCSpawner.npcCount = net.ReadInt(32)
            NPCSpawner.propModel = net.ReadString()
            NPCSpawner.enemyNPCClass = net.ReadString()

            ply:ChatPrint("NPC Spawner settings updated!")
        else
            ply:ChatPrint("You must be an admin to update settings.")
        end
    end)

    net.Receive("NPCSpawner_StartEvent", function(len, ply)
        if ply:IsAdmin() then
            NPCSpawner:StartEventSpawner()
            ply:ChatPrint("Event spawner started.")
        end
    end)

    net.Receive("NPCSpawner_StopEvent", function(len, ply)
        if ply:IsAdmin() then
            NPCSpawner:StopEventSpawner()
            ply:ChatPrint("Event spawner stopped.")
        end
    end)

    concommand.Add("npcspawner_adminmenu", function(ply)
        if ply:IsAdmin() then
            net.Start("NPCSpawner_OpenAdminMenu")
            net.Send(ply)
        else
            ply:ChatPrint("You must be an admin to access this menu.")
        end
    end)
else
    net.Receive("NPCSpawner_OpenAdminMenu", function()
        local frame = vgui.Create("DFrame")
        frame:SetTitle("NPC Spawner Admin Menu")
        frame:SetSize(400, 500)
        frame:Center()
        frame:MakePopup()

        local intervalLabel = vgui.Create("DLabel", frame)
        intervalLabel:SetText("Spawn Interval (seconds):")
        intervalLabel:Dock(TOP)

        local intervalSlider = vgui.Create("DNumSlider", frame)
        intervalSlider:SetMin(10)
        intervalSlider:SetMax(600)
        intervalSlider:SetDecimals(0)
        intervalSlider:SetValue(NPCSpawner.spawnInterval)
        intervalSlider:Dock(TOP)

        local npcClassLabel = vgui.Create("DLabel", frame)
        npcClassLabel:SetText("Standard NPC Class:")
        npcClassLabel:Dock(TOP)

        local npcClassText = vgui.Create("DTextEntry", frame)
        npcClassText:SetText(NPCSpawner.npcClass)
        npcClassText:Dock(TOP)

        local npcCountLabel = vgui.Create("DLabel", frame)
        npcCountLabel:SetText("NPC Count:")
        npcCountLabel:Dock(TOP)

        local npcCountSlider = vgui.Create("DNumSlider", frame)
        npcCountSlider:SetMin(1)
        npcCountSlider:SetMax(50)
        npcCountSlider:SetDecimals(0)
        npcCountSlider:SetValue(NPCSpawner.npcCount)
        npcCountSlider:Dock(TOP)

        local propModelLabel = vgui.Create("DLabel", frame)
        propModelLabel:SetText("Cargo Prop Model:")
        propModelLabel:Dock(TOP)

        local propModelText = vgui.Create("DTextEntry", frame)
        propModelText:SetText(NPCSpawner.propModel)
        propModelText:Dock(TOP)

        local enemyClassLabel = vgui.Create("DLabel", frame)
        enemyClassLabel:SetText("Cargo Enemy NPC Class:")
        enemyClassLabel:Dock(TOP)

        local enemyClassText = vgui.Create("DTextEntry", frame)
        enemyClassText:SetText(NPCSpawner.enemyNPCClass)
        enemyClassText:Dock(TOP)

        local applyButton = vgui.Create("DButton", frame)
        applyButton:SetText("Apply Settings")
        applyButton:Dock(TOP)
        applyButton.DoClick = function()
            net.Start("NPCSpawner_UpdateSettings")
            net.WriteInt(intervalSlider:GetValue(), 32)
            net.WriteString(npcClassText:GetText())
            net.WriteInt(npcCountSlider:GetValue(), 32)
            net.WriteString(propModelText:GetText())
            net.WriteString(enemyClassText:GetText())
            net.SendToServer()

            frame:Close()
        end

        local startButton = vgui.Create("DButton", frame)
        startButton:SetText("Start Event Spawner")
        startButton:Dock(TOP)
        startButton.DoClick = function()
            net.Start("NPCSpawner_StartEvent")
            net.SendToServer()
        end

        local stopButton = vgui.Create("DButton", frame)
        stopButton:SetText("Stop Event Spawner")
        stopButton:Dock(TOP)
        stopButton.DoClick = function()
            net.Start("NPCSpawner_StopEvent")
            net.SendToServer()
        end
    end)
end